#!/bin/bash

cd getaddrinfo 
./compile.sh
cd ../structure
./compile.sh